"use client"

import * as React from "react"
import { AppBar, Toolbar, Typography, Button, IconButton, Menu, MenuItem, Avatar } from "@mui/material"
import { Bell, MenuIcon } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/authContext"
import { useRouter } from "next/navigation"

export default function NavBar() {
  const { user, signOut } = useAuth()
  const router = useRouter()
  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null)
  const [notificationCount, setNotificationCount] = React.useState(0)

  const handleMenu = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget)
  }

  const handleClose = () => {
    setAnchorEl(null)
  }

  return (
    <AppBar position="static">
      <Toolbar>
        <IconButton size="large" edge="start" color="inherit" aria-label="menu" sx={{ mr: 2 }}>
          <MenuIcon />
        </IconButton>
        <Avatar
          src="https://sjc.microlink.io/mc7lNdiJunaeWFWcAiCNS-HpHAPU1SYWR-oHP-10Yjw1W_NPKomCxgLSEwfw2jD8nHh66WeQ56pQPUd37t3EVQ.jpeg"
          alt="WWCPS Logo"
          sx={{ width: 40, height: 40, mr: 2 }}
        />
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          WWCPS
        </Typography>
        {user ? (
          <>
            <IconButton color="inherit" onClick={() => router.push("/notifications")}>
              <Bell />
              {notificationCount > 0 && (
                <Typography
                  variant="caption"
                  sx={{
                    position: "absolute",
                    top: 0,
                    right: 0,
                    backgroundColor: "error.main",
                    borderRadius: "50%",
                    padding: "2px 6px",
                  }}
                >
                  {notificationCount}
                </Typography>
              )}
            </IconButton>
            <IconButton
              size="large"
              aria-label="account menu"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleMenu}
              color="inherit"
            >
              <Avatar sx={{ width: 32, height: 32 }}>{user.user_metadata.name?.[0] || user.email?.[0]}</Avatar>
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "right",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "right",
              }}
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
              <MenuItem onClick={() => router.push("/dashboard")}>Dashboard</MenuItem>
              <MenuItem onClick={() => router.push("/game-requests")}>Game Requests</MenuItem>
              <MenuItem onClick={signOut}>Logout</MenuItem>
            </Menu>
          </>
        ) : (
          <>
            <Button color="inherit" component={Link} href="/auth/signin">
              Login
            </Button>
            <Button color="inherit" component={Link} href="/auth/signup">
              Sign Up
            </Button>
          </>
        )}
      </Toolbar>
    </AppBar>
  )
}

