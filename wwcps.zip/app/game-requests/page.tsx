"use client"

import * as React from "react"
import { Container, Typography, TextField, Button, Alert, Paper } from "@mui/material"
import { useAuth } from "@/lib/authContext"

export default function GameRequests() {
  const { user } = useAuth()
  const [gameName, setGameName] = React.useState("")
  const [description, setDescription] = React.useState("")
  const [submitted, setSubmitted] = React.useState(false)
  const [error, setError] = React.useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSubmitted(false)

    try {
      const response = await fetch("/api/game-requests", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          gameName,
          description,
          userEmail: user?.email,
          userName: user?.user_metadata.name,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to submit game request")
      }

      setSubmitted(true)
      setGameName("")
      setDescription("")
    } catch (error) {
      setError("Failed to submit game request. Please try again.")
    }
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Submit Game Request
        </Typography>
        {submitted && (
          <Alert severity="success" sx={{ mb: 2 }}>
            Your game request has been submitted successfully!
          </Alert>
        )}
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        <form onSubmit={handleSubmit}>
          <TextField
            label="Game Name"
            variant="outlined"
            fullWidth
            margin="normal"
            value={gameName}
            onChange={(e) => setGameName(e.target.value)}
            required
          />
          <TextField
            label="Description"
            variant="outlined"
            fullWidth
            margin="normal"
            multiline
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>
            Submit Request
          </Button>
        </form>
      </Paper>
    </Container>
  )
}

