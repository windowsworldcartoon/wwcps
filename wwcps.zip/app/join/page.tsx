"use client"
import { Container, Typography, Button, Box, Paper } from "@mui/material"
import Image from "next/image"

export default function JoinPage() {
  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Box sx={{ textAlign: "center", mb: 4 }}>
          <Image
            src="https://sjc.microlink.io/mc7lNdiJunaeWFWcAiCNS-HpHAPU1SYWR-oHP-10Yjw1W_NPKomCxgLSEwfw2jD8nHh66WeQ56pQPUd37t3EVQ.jpeg"
            alt="WWCPS Logo"
            width={150}
            height={150}
          />
          <Typography variant="h4" component="h1" gutterBottom sx={{ mt: 2 }}>
            Join Windows World Cartoon Public Schools
          </Typography>
          <Typography variant="body1" paragraph>
            Join our community and be part of an amazing educational experience!
          </Typography>
        </Box>
        <Box sx={{ display: "flex", justifyContent: "center", gap: 2 }}>
          <Button
            variant="contained"
            color="primary"
            href="https://www.roblox.com/communities/14109521/windows-world-cartoon-public-schools#!/about"
            target="_blank"
            rel="noopener noreferrer"
          >
            Join on Roblox
          </Button>
          <Button variant="outlined" color="primary" href="/auth/signup">
            Create Account
          </Button>
        </Box>
      </Paper>
    </Container>
  )
}

