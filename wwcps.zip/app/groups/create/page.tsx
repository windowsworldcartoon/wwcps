"use client"

import * as React from "react"
import { Container, Typography, TextField, Button, Alert } from "@mui/material"
import { useAuth } from "@/lib/authContext"
import { useRouter } from "next/navigation"
import { supabase } from "@/lib/supabase"

export default function CreateGroup() {
  const [name, setName] = React.useState("")
  const [error, setError] = React.useState<string | null>(null)
  const { user } = useAuth()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    try {
      const { data, error } = await supabase.from("groups").insert({ name, owner_id: user?.id }).select()

      if (error) throw error

      router.push(`/groups/${data[0].id}`)
    } catch (error) {
      setError("Failed to create group")
    }
  }

  if (!user) {
    router.push("/auth/signin")
    return null
  }

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Create New Group
      </Typography>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      <form onSubmit={handleSubmit}>
        <TextField
          label="Group Name"
          variant="outlined"
          fullWidth
          margin="normal"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Button type="submit" variant="contained" fullWidth sx={{ mt: 2 }}>
          Create Group
        </Button>
      </form>
    </Container>
  )
}

