import { Container, Typography, Button } from "@mui/material"
import Link from "next/link"

export default function Shutdown({ params }: { params: { id: string } }) {
  return (
    <Container maxWidth="sm">
      <Typography variant="h2" component="h1" gutterBottom>
        Shutdown Group {params.id}
      </Typography>
      <Typography paragraph>Are you sure you want to shutdown this group? This action cannot be undone.</Typography>
      <Button variant="contained" color="error">
        Confirm Shutdown
      </Button>
      <Button
        component={Link}
        href={`/groups/${params.id}/dashboard`}
        variant="outlined"
        style={{ marginLeft: "1rem" }}
      >
        Cancel
      </Button>
    </Container>
  )
}

