"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  Container,
  Typography,
  Box,
  Tabs,
  Tab,
  Button,
  TextField,
  List,
  ListItem,
  ListItemText,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from "@mui/material"
import { useAuth } from "@/lib/authContext"
import { supabase } from "@/lib/supabase"

type Role = {
  id: string
  name: string
  permissions: any
}

type Channel = {
  id: string
  name: string
  type: string
}

type Message = {
  id: string
  content: string
  user_id: string
  created_at: string
}

export default function GroupPage({ params }: { params: { id: string } }) {
  const { user } = useAuth()
  const router = useRouter()
  const [group, setGroup] = useState<any>(null)
  const [roles, setRoles] = useState<Role[]>([])
  const [channels, setChannels] = useState<Channel[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [currentChannel, setCurrentChannel] = useState<string | null>(null)
  const [newMessage, setNewMessage] = useState("")
  const [tabValue, setTabValue] = useState(0)
  const [isOwner, setIsOwner] = useState(false)
  const [openRoleDialog, setOpenRoleDialog] = useState(false)
  const [newRoleName, setNewRoleName] = useState("")
  const [openChannelDialog, setOpenChannelDialog] = useState(false)
  const [newChannelName, setNewChannelName] = useState("")
  const [newChannelType, setNewChannelType] = useState("chat")
  const [customCode, setCustomCode] = useState("")

  useEffect(() => {
    if (user) {
      fetchGroupData()
      fetchRoles()
      fetchChannels()
    }
  }, [user]) // Removed params.id from dependencies

  const fetchGroupData = async () => {
    const { data, error } = await supabase.from("groups").select("*").eq("id", params.id).single()

    if (error) {
      console.error("Error fetching group:", error)
      return
    }

    setGroup(data)
    setIsOwner(data.owner_id === user?.id)
  }

  const fetchRoles = async () => {
    const { data, error } = await supabase.from("roles").select("*").eq("group_id", params.id)

    if (error) {
      console.error("Error fetching roles:", error)
      return
    }

    setRoles(data)
  }

  const fetchChannels = async () => {
    const { data, error } = await supabase.from("channels").select("*").eq("group_id", params.id)

    if (error) {
      console.error("Error fetching channels:", error)
      return
    }

    setChannels(data)
    if (data.length > 0 && !currentChannel) {
      setCurrentChannel(data[0].id)
    }
  }

  const fetchMessages = async (channelId: string) => {
    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("channel_id", channelId)
      .order("created_at", { ascending: true })

    if (error) {
      console.error("Error fetching messages:", error)
      return
    }

    setMessages(data)
  }

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue)
  }

  const handleSendMessage = async () => {
    if (!currentChannel || !newMessage.trim()) return

    const { error } = await supabase
      .from("messages")
      .insert({ channel_id: currentChannel, user_id: user?.id, content: newMessage })

    if (error) {
      console.error("Error sending message:", error)
      return
    }

    setNewMessage("")
    fetchMessages(currentChannel)
  }

  const handleCreateRole = async () => {
    if (!newRoleName.trim()) return

    const { error } = await supabase.from("roles").insert({ group_id: params.id, name: newRoleName, permissions: {} })

    if (error) {
      console.error("Error creating role:", error)
      return
    }

    setNewRoleName("")
    setOpenRoleDialog(false)
    fetchRoles()
  }

  const handleCreateChannel = async () => {
    if (!newChannelName.trim()) return

    const { error } = await supabase.from("channels").insert({
      group_id: params.id,
      name: newChannelName,
      type: newChannelType,
      custom_code: newChannelType === "custom" ? customCode : null,
    })

    if (error) {
      console.error("Error creating channel:", error)
      return
    }

    setNewChannelName("")
    setNewChannelType("chat")
    setCustomCode("")
    setOpenChannelDialog(false)
    fetchChannels()
  }

  const handleCloseGroup = async () => {
    const { error } = await supabase.from("groups").update({ is_closed: true }).eq("id", params.id)

    if (error) {
      console.error("Error closing group:", error)
      return
    }

    router.push("/dashboard")
  }

  if (!group) {
    return <Typography>Loading...</Typography>
  }

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>
        {group.name}
      </Typography>
      <Box sx={{ borderBottom: 1, borderColor: "divider", mb: 2 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Channels" />
          <Tab label="Roles" />
          <Tab label="Settings" />
        </Tabs>
      </Box>

      {tabValue === 0 && (
        <Box>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
            <Typography variant="h6">Channels</Typography>
            {isOwner && (
              <Button variant="contained" onClick={() => setOpenChannelDialog(true)}>
                Create Channel
              </Button>
            )}
          </Box>
          <List>
            {channels.map((channel) => (
              <ListItem
                key={channel.id}
                button
                selected={channel.id === currentChannel}
                onClick={() => {
                  setCurrentChannel(channel.id)
                  fetchMessages(channel.id)
                }}
              >
                <ListItemText primary={channel.name} secondary={`Type: ${channel.type}`} />
              </ListItem>
            ))}
          </List>
          {currentChannel && (
            <Box>
              <Typography variant="h6">Messages</Typography>
              <List>
                {messages.map((message) => (
                  <ListItem key={message.id}>
                    <ListItemText primary={message.content} secondary={new Date(message.created_at).toLocaleString()} />
                  </ListItem>
                ))}
              </List>
              <Box sx={{ display: "flex", mt: 2 }}>
                <TextField
                  fullWidth
                  variant="outlined"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type a message..."
                />
                <Button variant="contained" onClick={handleSendMessage} sx={{ ml: 1 }}>
                  Send
                </Button>
              </Box>
            </Box>
          )}
        </Box>
      )}

      {tabValue === 1 && (
        <Box>
          <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
            <Typography variant="h6">Roles</Typography>
            {isOwner && (
              <Button variant="contained" onClick={() => setOpenRoleDialog(true)}>
                Create Role
              </Button>
            )}
          </Box>
          <List>
            {roles.map((role) => (
              <ListItem key={role.id}>
                <ListItemText primary={role.name} />
              </ListItem>
            ))}
          </List>
        </Box>
      )}

      {tabValue === 2 && isOwner && (
        <Box>
          <Typography variant="h6">Settings</Typography>
          <Button variant="contained" color="secondary" onClick={handleCloseGroup}>
            Close Group
          </Button>
        </Box>
      )}

      <Dialog open={openRoleDialog} onClose={() => setOpenRoleDialog(false)}>
        <DialogTitle>Create New Role</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Role Name"
            fullWidth
            variant="outlined"
            value={newRoleName}
            onChange={(e) => setNewRoleName(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenRoleDialog(false)}>Cancel</Button>
          <Button onClick={handleCreateRole}>Create</Button>
        </DialogActions>
      </Dialog>

      <Dialog open={openChannelDialog} onClose={() => setOpenChannelDialog(false)}>
        <DialogTitle>Create New Channel</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Channel Name"
            fullWidth
            variant="outlined"
            value={newChannelName}
            onChange={(e) => setNewChannelName(e.target.value)}
          />
          <TextField
            select
            margin="dense"
            label="Channel Type"
            fullWidth
            variant="outlined"
            value={newChannelType}
            onChange={(e) => setNewChannelType(e.target.value)}
            SelectProps={{
              native: true,
            }}
          >
            <option value="chat">Chat</option>
            <option value="announcements">Announcements</option>
            <option value="custom">Custom</option>
          </TextField>
          {newChannelType === "custom" && (
            <TextField
              margin="dense"
              label="Custom Code (HTML/JS)"
              fullWidth
              variant="outlined"
              multiline
              rows={4}
              value={customCode}
              onChange={(e) => setCustomCode(e.target.value)}
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenChannelDialog(false)}>Cancel</Button>
          <Button onClick={handleCreateChannel}>Create</Button>
        </DialogActions>
      </Dialog>
    </Container>
  )
}

