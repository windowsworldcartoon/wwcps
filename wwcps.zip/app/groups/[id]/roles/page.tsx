"use client"

import { useState, useEffect } from "react"
import {
  Container,
  Typography,
  Paper,
  List,
  ListItem,
  ListItemText,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Checkbox,
  FormControlLabel,
} from "@mui/material"
import { useAuth } from "@/lib/authContext"
import { supabase } from "@/lib/supabase"

type Role = {
  id: string
  name: string
  permissions: {
    canManageChannels?: boolean
    canManageRoles?: boolean
    canInviteMembers?: boolean
    canRemoveMembers?: boolean
  }
}

export default function RolesPage({ params }: { params: { id: string } }) {
  const { user } = useAuth()
  const [roles, setRoles] = useState<Role[]>([])
  const [openDialog, setOpenDialog] = useState(false)
  const [newRole, setNewRole] = useState({
    name: "",
    permissions: {
      canManageChannels: false,
      canManageRoles: false,
      canInviteMembers: false,
      canRemoveMembers: false,
    },
  })

  useEffect(() => {
    fetchRoles()
  }, [])

  const fetchRoles = async () => {
    const { data, error } = await supabase.from("roles").select("*").eq("group_id", params.id)

    if (error) {
      console.error("Error fetching roles:", error)
      return
    }

    setRoles(data)
  }

  const handleCreateRole = async () => {
    const { error } = await supabase.from("roles").insert({
      group_id: params.id,
      name: newRole.name,
      permissions: newRole.permissions,
    })

    if (error) {
      console.error("Error creating role:", error)
      return
    }

    setOpenDialog(false)
    setNewRole({
      name: "",
      permissions: {
        canManageChannels: false,
        canManageRoles: false,
        canInviteMembers: false,
        canRemoveMembers: false,
      },
    })
    fetchRoles()
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Manage Roles
        </Typography>
        <Button variant="contained" color="primary" onClick={() => setOpenDialog(true)} sx={{ mb: 2 }}>
          Create New Role
        </Button>
        <List>
          {roles.map((role) => (
            <ListItem key={role.id}>
              <ListItemText
                primary={role.name}
                secondary={
                  <Typography variant="body2" component="div">
                    Permissions:
                    <ul>
                      {Object.entries(role.permissions).map(([key, value]) => (
                        <li key={key}>
                          {key}: {value ? "Yes" : "No"}
                        </li>
                      ))}
                    </ul>
                  </Typography>
                }
              />
            </ListItem>
          ))}
        </List>
      </Paper>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>Create New Role</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Role Name"
            fullWidth
            variant="outlined"
            value={newRole.name}
            onChange={(e) => setNewRole({ ...newRole, name: e.target.value })}
          />
          <Typography variant="subtitle1" sx={{ mt: 2 }}>
            Permissions
          </Typography>
          <FormControlLabel
            control={
              <Checkbox
                checked={newRole.permissions.canManageChannels}
                onChange={(e) =>
                  setNewRole({
                    ...newRole,
                    permissions: {
                      ...newRole.permissions,
                      canManageChannels: e.target.checked,
                    },
                  })
                }
              />
            }
            label="Can Manage Channels"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={newRole.permissions.canManageRoles}
                onChange={(e) =>
                  setNewRole({
                    ...newRole,
                    permissions: {
                      ...newRole.permissions,
                      canManageRoles: e.target.checked,
                    },
                  })
                }
              />
            }
            label="Can Manage Roles"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={newRole.permissions.canInviteMembers}
                onChange={(e) =>
                  setNewRole({
                    ...newRole,
                    permissions: {
                      ...newRole.permissions,
                      canInviteMembers: e.target.checked,
                    },
                  })
                }
              />
            }
            label="Can Invite Members"
          />
          <FormControlLabel
            control={
              <Checkbox
                checked={newRole.permissions.canRemoveMembers}
                onChange={(e) =>
                  setNewRole({
                    ...newRole,
                    permissions: {
                      ...newRole.permissions,
                      canRemoveMembers: e.target.checked,
                    },
                  })
                }
              />
            }
            label="Can Remove Members"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button onClick={handleCreateRole} variant="contained">
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  )
}

