"use client"

import * as React from "react"
import { Container, Typography, Button, Alert, Paper, Grid } from "@mui/material"
import Link from "next/link"
import { useAuth } from "@/lib/authContext"
import { useRouter } from "next/navigation"

type Group = {
  id: string
  name: string
  ownerId: string
}

export default function GroupDashboard({ params }: { params: { id: string } }) {
  const { user } = useAuth()
  const router = useRouter()
  const [group, setGroup] = React.useState<Group | null>(null)
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    const fetchGroup = async () => {
      try {
        // Simulating an API call
        const response = await fetch(`/api/groups/${params.id}`)
        if (!response.ok) {
          throw new Error("Failed to fetch group")
        }
        const data = await response.json()
        setGroup(data)
      } catch (error) {
        setError("Failed to load group")
      }
    }

    fetchGroup()
  }, [params.id])

  if (!user) {
    router.push("/auth/signin")
    return null
  }

  if (error) {
    return <Alert severity="error">{error}</Alert>
  }

  if (!group) {
    return <Typography>Loading...</Typography>
  }

  const isOwner = user.id === group.ownerId

  return (
    <Container maxWidth="md">
      <Typography variant="h2" component="h1" gutterBottom>
        {group.name}
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} style={{ padding: "1rem", marginBottom: "1rem" }}>
            <Typography variant="h6" gutterBottom>
              Group Details
            </Typography>
            <Typography>ID: {group.id}</Typography>
            <Typography>Owner: {isOwner ? "You" : "Another user"}</Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={6}>
          <Paper elevation={3} style={{ padding: "1rem", marginBottom: "1rem" }}>
            <Typography variant="h6" gutterBottom>
              Actions
            </Typography>
            <Button
              component={Link}
              href={`/groups/${params.id}/dev`}
              variant="contained"
              fullWidth
              style={{ marginBottom: "0.5rem" }}
            >
              Enter Dev Mode
            </Button>
            {isOwner && (
              <Button
                component={Link}
                href={`/groups/${params.id}/shutdown`}
                variant="outlined"
                color="secondary"
                fullWidth
              >
                Shutdown
              </Button>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  )
}

