"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Container, Typography, Box, TextField, Button } from "@mui/material"
import { useAuth } from "@/lib/authContext"
import { supabase } from "@/lib/supabase"

export default function DevMode({ params }: { params: { id: string } }) {
  const { user } = useAuth()
  const router = useRouter()
  const [group, setGroup] = useState<any>(null)
  const [code, setCode] = useState("")
  const [output, setOutput] = useState("")

  useEffect(() => {
    if (user) {
      fetchGroupData()
    }
  }, [user]) // Removed unnecessary dependency: params.id

  const fetchGroupData = async () => {
    const { data, error } = await supabase.from("groups").select("*").eq("id", params.id).single()

    if (error) {
      console.error("Error fetching group:", error)
      return
    }

    setGroup(data)
  }

  const handleRunCode = () => {
    try {
      // This is a simple evaluation. In a real-world scenario,
      // you'd want to use a sandboxed environment for security.
      const result = eval(code)
      setOutput(String(result))
    } catch (error) {
      setOutput(`Error: ${error}`)
    }
  }

  if (!group) {
    return <Typography>Loading...</Typography>
  }

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" component="h1" gutterBottom>
        Dev Mode - {group.name}
      </Typography>
      <Box sx={{ mb: 2 }}>
        <TextField
          fullWidth
          multiline
          rows={10}
          variant="outlined"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="Enter your code here..."
        />
      </Box>
      <Button variant="contained" onClick={handleRunCode}>
        Run Code
      </Button>
      <Box sx={{ mt: 2 }}>
        <Typography variant="h6">Output:</Typography>
        <pre>{output}</pre>
      </Box>
    </Container>
  )
}

