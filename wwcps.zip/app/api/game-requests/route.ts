import { NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { gameName, description, userEmail, userName } = body

    // Send email using your preferred email service
    // For demonstration, we'll just log it
    console.log(`
      New Game Request:
      From: ${userName} (${userEmail})
      Game Name: ${gameName}
      Description: ${description}
    `)

    // Store in Supabase
    const { error } = await supabase.from("game_requests").insert({
      game_name: gameName,
      description,
      user_email: userEmail,
      user_name: userName,
    })

    if (error) throw error

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing game request:", error)
    return NextResponse.json({ error: "Failed to process game request" }, { status: 500 })
  }
}

