import { NextResponse } from "next/server"

const groups = [
  {
    id: "12935",
    name: "Fire Alarm Home 2025 edition",
    ownerId: "1", // Assuming '1' is the ID of the owner
  },
]

export async function GET() {
  return NextResponse.json(groups)
}

export async function POST(request: Request) {
  const body = await request.json()
  const newGroup = {
    id: (Number.parseInt(groups[groups.length - 1].id) + 1).toString(),
    name: body.name,
    ownerId: body.ownerId,
  }
  groups.push(newGroup)
  return NextResponse.json(newGroup, { status: 201 })
}

