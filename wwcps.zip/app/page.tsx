import { Button, Container, Typography } from "@mui/material"
import Link from "next/link"

export default function Home() {
  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h2" component="h1" gutterBottom>
        Welcome to WWCPS
      </Typography>
      <Typography variant="body1" paragraph>
        Your platform for collaborative project spaces.
      </Typography>
      <Button component={Link} href="/auth/signin" variant="contained" fullWidth sx={{ mb: 2 }}>
        Sign In
      </Button>
      <Button component={Link} href="/auth/signup" variant="outlined" fullWidth>
        Sign Up
      </Button>
    </Container>
  )
}

