"use client"

import * as React from "react"
import { Container, Typography, List, ListItem, ListItemButton, ListItemText, Button, Alert, Box } from "@mui/material"
import { useAuth } from "@/lib/authContext"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { supabase } from "@/lib/supabase"

type Group = {
  id: string
  name: string
}

export default function Dashboard() {
  const { user, signOut } = useAuth()
  const router = useRouter()
  const [groups, setGroups] = React.useState<Group[]>([])
  const [error, setError] = React.useState<string | null>(null)

  React.useEffect(() => {
    const fetchGroups = async () => {
      try {
        const { data, error } = await supabase.from("groups").select("*").eq("owner_id", user?.id)

        if (error) throw error
        setGroups(data)
      } catch (error) {
        setError("Failed to load groups")
      }
    }

    if (user) {
      fetchGroups()
    }
  }, [user])

  if (!user) {
    router.push("/auth/signin")
    return null
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Dashboard
      </Typography>
      <Typography variant="h6" gutterBottom>
        Welcome, {user.user_metadata.name || user.email}!
      </Typography>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      <Box sx={{ mb: 2 }}>
        <Typography variant="h6" gutterBottom>
          Your Groups
        </Typography>
        {groups.length === 0 ? (
          <Typography>You haven't created any groups yet.</Typography>
        ) : (
          <List>
            {groups.map((group) => (
              <ListItem key={group.id} disablePadding>
                <ListItemButton component={Link} href={`/groups/${group.id}`}>
                  <ListItemText primary={group.name} />
                </ListItemButton>
                <Button component={Link} href={`/groups/${group.id}/dev`} variant="outlined" sx={{ ml: 2 }}>
                  Dev Mode
                </Button>
              </ListItem>
            ))}
          </List>
        )}
      </Box>
      <Box sx={{ display: "flex", gap: 2 }}>
        <Button variant="contained" color="primary" onClick={() => router.push("/groups/create")}>
          Create New Group
        </Button>
        <Button variant="outlined" color="secondary" onClick={signOut}>
          Logout
        </Button>
      </Box>
    </Container>
  )
}

